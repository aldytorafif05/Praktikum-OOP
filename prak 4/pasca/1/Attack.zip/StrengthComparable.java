public interface StrengthComparable {
    public int compareStrength(StrengthComparable other);
}
