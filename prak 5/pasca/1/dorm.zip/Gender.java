public enum Gender {
    PRIA,
    WANITA
}
