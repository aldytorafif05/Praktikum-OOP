public enum UsageType{
    SERVER, DEVELOPMENT, GAMING;
}