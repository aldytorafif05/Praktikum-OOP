class SpellCastFailedException extends Exception {
    public SpellCastFailedException(String message, Throwable cause) {
        super(message, cause);
    }
}