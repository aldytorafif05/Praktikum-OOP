public interface TeamMember {
    String getName();
    int getSkillLevel();
    void performTask(String task);
}